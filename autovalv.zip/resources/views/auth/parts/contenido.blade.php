<section class="mt-3">
    <div class="container-fluid">
        @include( 'auth.parts.contenido.' . $data[ "section" ] )
    </div>
</section>