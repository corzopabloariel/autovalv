<div class="d-flex h-100 align-items-center justify-content-center py-5">
    <h1>Bienvenido<br/>{{Auth::user()["name"]}}</h1>
</div>