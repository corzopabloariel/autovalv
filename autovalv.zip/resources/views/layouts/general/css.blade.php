<link rel="dns-prefetch" href="//fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Quattrocento+Sans:400,400i,700&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,400i,700&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700&display=swap" rel="stylesheet">
<!-- Styles -->
<link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
<link href="https://select2.github.io/select2-bootstrap-theme/css/select2-bootstrap.css" rel="stylesheet">
<link href="https://csshake.surge.sh/csshake.min.css" rel="stylesheet" type="text/css">
<link href="{{ asset('css/alertifyjs/alertify.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/alertifyjs/themes/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/slick.css') }}" rel="stylesheet">
<link href="{{ asset('css/slick-theme.css') }}" rel="stylesheet">
<script src="https://kit.fontawesome.com/773d0bcede.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">

<link href="{{ asset('css/css.css') }}" rel="stylesheet">
<link href="{{ asset('css/adm.css') }}" rel="stylesheet">
<link href="{{ asset('css/nav.css') }}" rel="stylesheet">