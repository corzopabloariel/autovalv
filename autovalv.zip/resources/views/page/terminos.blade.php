<div class="wrapper-terminos bg-white font-lato wrapper-">
    <div class="container">
        <div class="row pb-5 mt-0 wrapper- normal">
            <div class="col-12">
                <h3 class="title">{{ $data[ "contenido" ]->content[ "title" ] }}</h3>
                <div class="mt-4 text">
                    {!! $data[ "contenido" ]->content[ "text" ] !!}
                </div>
            </div>
        </div>
    </div>
</div>