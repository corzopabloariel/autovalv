<div class="card mt-2" id="wrapper-tabla">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table mb-0" id="tabla"></table>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/layouts/general/table.blade.php ENDPATH**/ ?>