<div class="wrapper-home bg-white" style="padding-top: 15px;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-md-8 pl-0">
                <div id="carouselExampleIndicators" class="carousel bg-white slide wrapper-slider" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <?php for($i = 0 ; $i < count($data['sliders']) ; $i++): ?>
                            <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="<?php if($i == 0): ?> active <?php endif; ?>"></li>
                        <?php endfor; ?>
                    </ol>
                    <div class="carousel-inner">
                        <?php for($i = 0 ; $i < count($data['sliders']) ; $i++): ?>
                        <div class="carousel-item <?php if($i == 0): ?> active <?php endif; ?>">
                            <img class="d-block w-100" src="<?php echo e(asset($data['sliders'][$i]['image'][ 'i' ])); ?>" >
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md px-0 d-flex align-items-stretch flex-column justify-content-between">
                <div class="cotizacion" style="background-image: url(<?php echo e(asset( 'images/general/cotizacion.jpg' )); ?>); background-position: center center; background-repeat: no-repeat; background-size: cover;"></div>
                <div class="buscador" style="background-image: url(<?php echo e(asset( 'images/general/buscador.jpg' )); ?>); background-position: center center; background-repeat: no-repeat; background-size: cover;"></div>
            </div>
        </div>
    </div>
    <div class="container destacado py-4">
        <h3 class="title text-center font-lato">
            <span>PRODUCTOS DESTACADOS</span>
        </h3>
    </div>
    <div class="iconos">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <ul class="list-group py-4 list-group-horizontal d-flex justify-content-center icon border-0">
                        <?php $__currentLoopData = $data[ "contenido" ]->content[ 'icon' ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex bg-transparent align-items-center flex-column px-5 border-0">
                                <?php if(isset( $c[ 'icon' ][ 'i' ] )): ?>
                                <img src="<?php echo e(asset( $c[ 'icon' ][ 'i' ] )); ?>" alt="icon" class="mb-2" srcset="">
                                <?php endif; ?>
                                <p class="mx-auto text-center"><?php echo $c[ 'text' ]; ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/home.blade.php ENDPATH**/ ?>