<!DOCTYPE html>
<html>
<body>
    <?php if( isset( $producto ) ): ?>
        <h3>Consulta de producto:</h3>
        <a target="blank" href="<?php echo e(URL::to( 'productos/' . str_slug( $producto->familia->title ) . '/' . str_slug( $producto->title ) . '/' . $producto->id )); ?>">
            <?php echo $producto->title; ?>

        </a>
    <?php else: ?>
        <h3>Datos de contacto</h3>
    <?php endif; ?>
	<ul>
        <li><strong>Nombre:</strong> <?php echo e($nombre); ?> <?php echo e($apellido); ?></li>
        <li><strong>Empresa:</strong> <?php echo e($empresa); ?></li>
        <li><strong>Email:</strong> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></li>
        <li><strong>Teléfono:</strong> <?php echo e($telefono); ?></li>
	</ul>
    <br>
    <h4>Mensaje</h4>
    <p><?php echo e($mensaje); ?></p>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/form/contacto.blade.php ENDPATH**/ ?>