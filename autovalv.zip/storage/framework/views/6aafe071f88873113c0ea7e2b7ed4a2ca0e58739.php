<div class="wrapper-contacto bg-white font-lato wrapper-">
    <div class="container">
        <div class="row SinEspacio">
            <div class="col-12 col-md d-flex align-items-stretch">
                <div class="title text-uppercase position-relative font-lato w-100 d-flex align-items-center">
                    <div class="position-absolute w-100 h-100"></div>
                    <div class="w-100 p-4">
                        contacto
                    </div>
                </div>
            </div>
            <?php echo $__env->make( 'layouts.general.dato' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
        <div class="row SinEspacio">
            <div class="col-12">
                <div class="pb-4 wrapper-">
                    <form action="<?php echo e(route( 'contacto' )); ?>" method="post" class="form p-4">
                        <?php echo csrf_field(); ?>
                        <div class="p-4">
                            <div class="row normal">
                                <div class="col-12 col-lg-8">
                                    <?php if(isset( $data[ "producto" ] )): ?>
                                    <input type="hidden" name="producto_id" value="<?php echo e($data[ 'producto' ]->id); ?>" />
                                    <div class="row normal">
                                        <div class="col-12 col-md">
                                            <h3 class="title-form border-bottom-0">Consulta del producto</h3>
                                            <div class="text-center">
                                                <?php echo $data[ "producto" ]->title; ?>

                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="row normal">
                                        <div class="col-12 col-md">
                                            <input required type="text" name="nombre" class="form-control" placeholder="Nombre (*)">
                                        </div>
                                        <div class="col-12 col-md">
                                            <input required type="text" name="apellido" class="form-control" placeholder="Apellido (*)">
                                        </div>
                                    </div>
                                    <div class="row normal mt-4">
                                        <div class="col-12 col-md">
                                            <input required type="text" name="empresa" class="form-control" placeholder="Empresa">
                                        </div>
                                        <div class="col-12 col-md">
                                            <select required class="form-control" name="tipo" id="">
                                                <option value="" hidden selected>Tipo de Cliente (*)</option>
                                                <option>Usuario</option>
                                                <option>Instalador</option>
                                                <option>Revendedor</option>
                                                <option>Distribuidor</option>
                                                <option>Fabricante</option>
                                                <option>Otros</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row normal mt-4">
                                        <div class="col-12 col-md">
                                            <input required type="email" name="email" class="form-control" placeholder="Email (*)">
                                        </div>
                                        <div class="col-12 col-md">
                                            <input type="phone" name="telefono" class="form-control" placeholder="Teléfono">
                                        </div>
                                    </div>
                                    <div class="row normal mt-4">
                                        <div class="col-12 col-md">
                                            <textarea name="mensaje" id="" class="form-control" placeholder="Mensaje" rows="4"></textarea>
                                        </div>
                                    </div>
                                    <div class="row normal mt-4">
                                        <div class="col-12 terminos">
                                            <div class="mt-2"><?php echo $data[ "terminos" ]->content[ "frase" ]; ?></div>
                                        </div>
                                        <div class="col-12 d-flex justify-content-center mt-4">
                                            <button type="submit" class="btn btn-danger font-lato text-uppercase px-5 text-white rounded-pill">enviar</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg">
                                    <ul class="list-unstyled info mb-0 pl-4">
                                        <li class="d-flex">
                                            <i class="icono fas fa-info-circle"></i>
                                            <div class="" style="width: calc(100% - 37px)" >
                                                <h4>Atención al Público</h4>
                                                <?php echo e($data[ 'empresa' ]->schedule[ 'publico' ]); ?>

                                                <h4 class="mt-2">Expedición de Mercadería</h4>
                                                <?php echo e($data[ 'empresa' ]->schedule[ 'mercaderia' ]); ?>

                                            </div>
                                        </li>
                                        <li class="d-flex mt-4">
                                            <i class="icono fas fa-map-marker-alt"></i>
                                            <div class="" style="width: calc(100% - 37px)" >
                                                <p class="mb-0"><a href="<?php echo e($data[ 'empresa' ]->domicile[ 'link' ]); ?>" target="blank"><?php echo e($data[ 'empresa' ]->domicile["calle"]); ?> <?php echo e($data[ 'empresa' ]->domicile["altura"]); ?> <?php if(!empty($data[ 'empresa' ]->domicile["cp"])): ?> (<?php echo e($data[ 'empresa' ]->domicile["cp"]); ?>)<?php endif; ?><br><?php echo e($data[ 'empresa' ]->domicile["provincia"]); ?><?php if(!empty($data[ 'empresa' ]->domicile["localidad"])): ?> - <?php echo e($data[ 'empresa' ]->domicile["localidad"]); ?><?php endif; ?> | <?php echo e($data[ 'empresa' ]->domicile["pais"]); ?></a></p>
                                            </div>
                                        </li>
                                            <?php
                                        $A_tel = $A_wha = [];
                                        foreach($data["empresa"]->phone AS $t) {
                                            if($t["tipo"] == "tel")
                                                $A_tel[] = $t;
                                            else
                                                $A_wha[] = $t;
                                        }
                                        ?>
                                        <li class="d-flex mt-4">
                                            <i class="icono fas fa-phone-volume"></i>
                                            <div class="" style="width: calc(100% - 37px)">
                                                <?php $__currentLoopData = $A_tel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    $visible = $t[ "telefono" ];
                                                    $telefono = $t[ "telefono" ];
                                                    if( !empty( $t[ "visible" ] ) )
                                                        $visible = $t[ "visible" ];
                                                    ?>
                                                    <?php if( $t[ "is_link" ] ): ?>
                                                        <a title="<?php echo e($visible); ?>" class="text-truncate d-block" href="tel:<?php echo e($telefono); ?>"><?php echo e($visible); ?></a>
                                                    <?php else: ?>
                                                        <?php echo e($visible); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </li>
                                        <?php if(!empty($A_wha)): ?>
                                        <li class="d-flex mt-4">
                                            <i class="icono fab fa-whatsapp"></i>
                                            <div class="" style="width: calc(100% - 37px)">
                                                <?php $__currentLoopData = $A_wha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a title="<?php echo e($t['visible']); ?>" class="whatsapp text-truncate d-block" href="https://wa.me/<?php echo $t['telefono']; ?>"><?php echo e($t["visible"]); ?></a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php echo $data[ "empresa" ]->domicile[ "mapa" ]; ?>

</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/contacto.blade.php ENDPATH**/ ?>