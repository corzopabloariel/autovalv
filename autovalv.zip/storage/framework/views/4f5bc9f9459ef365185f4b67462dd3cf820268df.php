<div class="wrapper-empresa bg-white font-lato" style="padding-top: 15px;">
    <div id="carouselExampleIndicators" class="carousel bg-white slide wrapper-slider" data-ride="carousel">
        <ol class="carousel-indicators">
            <?php for($i = 0 ; $i < count($data['sliders']) ; $i++): ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="<?php if($i == 0): ?> active <?php endif; ?>"></li>
            <?php endfor; ?>
        </ol>
        <div class="carousel-inner">
            <?php for($i = 0 ; $i < count($data['sliders']) ; $i++): ?>
            <div class="carousel-item <?php if($i == 0): ?> active <?php endif; ?>">
                <img class="d-block w-100" src="<?php echo e(asset($data['sliders'][$i]['image'][ 'i' ])); ?>" >
            </div>
            <?php endfor; ?>
        </div>
    </div>
    <div class="container">
        <div class="row py-4">
            <div class="col-12 col-md d-flex align-items-stretch">
                <div class="title text-uppercase position-relative font-lato w-100 d-flex align-items-center">
                    <div class="position-absolute w-100 h-100"></div>
                    <div class="w-100 p-4">
                        la empresa
                    </div>
                </div>
            </div>
            <?php echo $__env->make( 'layouts.general.dato' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="row pb-5 mt-0">
            <div class="col-12 text-justify contenido">
                <?php echo $data[ "contenido" ]->content[ "text1" ]; ?>

                <div class="frase1 my-4 text-center font-roboto">
                    <?php echo $data[ "contenido" ]->content[ "phrase1" ]; ?>

                </div>
                <?php echo $data[ "contenido" ]->content[ "text2" ]; ?>

                <div class="frase2 text-center mx-auto px-3 my-4">
                    <?php echo $data[ "contenido" ]->content[ "phrase2" ]; ?>

                </div>
                <img src="<?php echo e(asset( $data[ 'contenido' ]->content[ 'image' ][ 'i' ] )); ?>" onerror="this.src='<?php echo e(asset(`images/general/no-image-icon.png`)); ?>'" alt="La empresa" srcset="">
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/empresa.blade.php ENDPATH**/ ?>