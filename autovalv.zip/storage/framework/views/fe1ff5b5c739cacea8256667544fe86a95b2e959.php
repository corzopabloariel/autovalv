<section class="mt-3">
    <div class="container-fluid">
        <?php echo $__env->make( 'layouts.general.form' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make( 'layouts.general.table' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>
<?php $__env->startPush('scripts'); ?>
<script>
    window.pyrus = new Pyrus( window.data.familia_id === null ? "familia" : "subfamilia" , null , src );

    familiasFunction = ( t , id ) => {
        window.location = `${url_simple}/adm/familias/${id}/sub`;
    };
    
    /** */
    init( () => { } );
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/auth/parts/familia.blade.php ENDPATH**/ ?>