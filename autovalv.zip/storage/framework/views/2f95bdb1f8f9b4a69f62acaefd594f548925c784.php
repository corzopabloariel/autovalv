<div class="wrapper-productos bg-white font-lato wrapper-">
    <div class="container">
        <div class="row SinEspacio hidden-mobile">
            <div class="col-12 col-md d-flex align-items-stretch">
                <div class="title text-uppercase position-relative font-lato w-100 d-flex align-items-center">
                    <div class="position-absolute w-100 h-100"></div>
                    <div class="w-100 p-4">
                        Buscador
                    </div>
                </div>
            </div>
            <?php echo $__env->make( 'layouts.general.dato' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="row wrapper- pb-5 mt-0">
            <?php $__empty_1 = true; $__currentLoopData = $data[ "elementos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $images = $p->images;
                    $img = "";
                    if( count( $images ) > 0)
                        $img = $images[ 0 ]->image[ 'i' ];
                ?>
                <div class="col-12 col-md-4 col-lg-3 mt-4 producto wrapper-link">
                    <a href="<?php echo e(URL::to( 'productos/' . str_slug( strip_tags( $p->familia->title ) ) . '/' . str_slug( strip_tags( $p->title ) ) . '/' . $p->id )); ?>">
                        <div class="card">
                            <img src="<?php echo e(asset( $img )); ?>" alt="" class="card-img-top border-bottom-0">
                            <div class="card-body">
                                <?php echo $p->title; ?>

                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center py-5">
                    <h3 class="py-5">Sin resultados para <strong>"<?php echo e($data[ "buscar" ]); ?>"</strong></h3>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/search.blade.php ENDPATH**/ ?>