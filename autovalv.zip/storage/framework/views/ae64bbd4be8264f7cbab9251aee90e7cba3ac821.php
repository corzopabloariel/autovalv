<section class="mt-3">
    <div class="container-fluid">
        <div class="card mb-2">
            <div class="card-body">
                <div class="wrapper-documentacion bg-white font-lato">
                    <div class="container">
                        <div class="row">
                            <?php $__currentLoopData = $data[ "elementos" ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 col-md-4 col-lg-3 text-center">
                                <div class="card mx-auto border-0">
                                    <img src="<?php echo e(asset( $d->cover[ 'i' ])); ?>" alt="" class="card-img-top border border-bottom-0">
                                    <div class="card-body border">
                                        <?php echo e($d->title); ?>

                                    </div>
                                    <?php if( file_exists( public_path() . "/" . $d->file[ 'i' ] ) ): ?>
                                    <div class="card-footer d-flex justify-content-around border-0 bg-transparent">
                                        <a href="<?php echo e(asset( $d->file[ 'i' ] )); ?>" target="blank"><i class="fas fa-eye"></i></a>
                                        <a href="<?php echo e(asset( $d->file[ 'i' ] )); ?>" download><i class="fas fa-download"></i></a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make( 'layouts.general.form' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make( 'layouts.general.table' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>
<?php $__env->startPush('scripts'); ?>
<script>
    window.pyrus = new Pyrus( "documentacion" , null , src );
    
    /** -------------------------------------
     *      INICIO
     ** ------------------------------------- */
    init( () => {} );
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/auth/parts/documentacion.blade.php ENDPATH**/ ?>