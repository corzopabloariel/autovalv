<div class="wrapper-productos bg-white font-lato wrapper-">
    <div class="container">
        <div class="row SinEspacio">
            <div class="col-12 col-md d-flex align-items-stretch">
                <div class="title text-uppercase position-relative font-lato w-100 d-flex align-items-center">
                    <div class="position-absolute w-100 h-100"></div>
                    <div class="w-100 p-4">
                        productos
                    </div>
                </div>
            </div>
            <?php echo $__env->make( 'layouts.general.dato' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="row py-5 mt-0 wrapper- SinEspacio">
            <div class="col-12 col-md-3">
                <div class="sidebar dont-collapse-sm" id="accordionMenu">
                    <ul class="list-group list-group-flush menu-lateral">
                    <?php $__currentLoopData = $data[ "familias" ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item p-0" id="heading_<?php echo e($m->id); ?>">
                        <div class="d-flex p-3 align-items-center justify-content-between collapsed" data-toggle="collapse" data-target="#collapse_<?php echo e($m->id); ?>" <?php if( $data[ 'familia' ]->id == $m->id ): ?> aria-expanded="true" <?php else: ?> aria-expanded="false" <?php endif; ?>>
                            <?php
                            $productos = $m->productos;
                            ?>
                            <a href="<?php echo e(URL::to( 'productos/' . str_slug( strip_tags( $m->title ) ) . '/' . $m->id )); ?>">
                                <?php echo $m->title; ?>

                            </a>
                            <?php if( count( $productos ) > 0 ): ?>
                            <i class="fas fa-angle-right"></i>
                            <?php endif; ?>
                        </div>
                        <?php if( count( $productos ) > 0 ): ?>
                            <ul class="list-group collapse <?php if( $data[ 'familia' ]->id == $m->id ): ?> show <?php endif; ?>" id="collapse_<?php echo e($m->id); ?>"  aria-labelledby="heading_<?php echo e($m->id); ?>" data-parent="#accordionMenu">
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item p-0">
                                <a href="<?php echo e(URL::to( 'productos/' . str_slug( strip_tags( $m->title ) ) . '/' . str_slug( strip_tags( $f->title ) ) . '/' . $f->id )); ?>" class="p-3 d-block">
                                    <i class="fas fa-arrow-right mr-2"></i><?php echo $f->title; ?>

                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-12 col-md-9">
                <div class="row normal mt-n4">
                    <?php $__currentLoopData = $data[ "productos" ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $images = $p->images;
                            $img = "";
                            if( count( $images ) > 0)
                                $img = $images[ 0 ]->image[ 'i' ];
                        ?>
                        <div class="col-12 col-md-6 col-lg-4 mt-4 producto wrapper-link">
                            <a href="<?php echo e(URL::to( 'productos/' . str_slug( $data['familia']->title ) . '/' . str_slug( $p->title ) . '/' . $p->id )); ?>">
                                <div class="card">
                                    <img src="<?php echo e(asset( $img )); ?>" alt="" class="card-img-top border-bottom-0">
                                    <div class="card-body">
                                        <?php echo $p->title; ?>

                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/familia.blade.php ENDPATH**/ ?>