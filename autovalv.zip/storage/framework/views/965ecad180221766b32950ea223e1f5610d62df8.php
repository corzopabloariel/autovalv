<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="<?php echo e($data['metadato']['description']); ?>"/>
        <meta name=”keywords” content="<?php echo e($data['metadato']['keywords']); ?>"/>
        <title><?php echo $__env->yieldContent( 'headTitle' , config( 'app.name' ) . ' :: ' . $data[ 'title' ] ); ?></title>
        
        <?php if( !empty( $data[ "empresa" ][ "images" ][ "favicon" ] ) ): ?>
            <?php if( $data[ "empresa" ][ "images" ][ "favicon" ][ "e" ] == "png" ): ?>
            <link rel="icon" type="image/png" href="<?php echo e(asset($data[ 'empresa' ][ 'images' ][ 'favicon' ][ 'i' ] )); ?>" />
            <?php else: ?>
            <link rel="shortcut icon" href="<?php echo e(asset( $data[ 'empresa' ][ 'images' ][ 'favicon' ][ 'i' ] )); ?>" />
            <?php endif; ?>
        <?php endif; ?>
        <!-- <Styles> -->
        <?php echo $__env->make( 'layouts.general.css' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/loading.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/loading-btn.css')); ?>">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">
        <link href="<?php echo e(asset('css/css.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/page/page.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/page/header.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/page/footer.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/page/responsive.css')); ?>" rel="stylesheet">
        <?php echo $__env->yieldPushContent( 'styles' ); ?>
        <!-- </Styles> -->
    </head>
    <body>
        <div class="modal fade bd-example-modal-lg" id="terminosModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
                <div class="modal-content">
                    <div class="modal-header bg-light">
                        <h5 class="modal-title"><?php echo e($data[ "terminos" ]->content[ "title" ]); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php echo $data[ "terminos" ]->content[ "text" ]; ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="modal" id="modal-pass" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header bg-danger">
                        <h5 class="modal-title">ATENCIÓN</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>Se le aconseja cambiar la contraseña desde la sección <a class="text-primary" href="">MIS DATOS</a></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        <?php if(isset( $data[ "whatsapp" ] )): ?>
        <a target="blank" href="https://wa.me/<?php echo e($data[ 'whatsapp' ][ 'telefono' ]); ?>" class="whatsapp-flotante shadow rounded-circle position-fixed d-flex justify-content-center align-items-center text-white"><i class="fab fa-whatsapp"></i></a>
        <?php endif; ?>
        <?php echo $__env->make( 'layouts.general.message' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="">
            <?php echo $__env->make( 'layouts.general.header' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <section>
            <?php echo $__env->make( $data[ 'view' ] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
            <?php echo $__env->make( 'layouts.general.footer' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- Scripts -->
        <?php echo $__env->make( 'layouts.general.script' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            window.url = "<?php echo e(url()->current()); ?>";
            $(document).ready(function() {
                if($("nav .menu").find(`a[href="${window.url}"]`).length)
                    $("nav .menu").find(`a[href="${window.url}"]`).addClass("active");
                $("body").on("click",".alert button.close", function() {
                    $(this).closest(".alert").remove();
                });
            });
        </script>
        <?php echo $__env->yieldPushContent( 'scripts' ); ?>
        <script src="<?php echo e(asset('js/bootstrap-autocomplete.js')); ?>"></script>
    </body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/layouts/main.blade.php ENDPATH**/ ?>