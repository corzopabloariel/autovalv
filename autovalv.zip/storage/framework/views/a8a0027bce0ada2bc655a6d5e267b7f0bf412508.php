<div class="wrapper-productos wrapper- bg-white font-lato">
    <div class="container">
        <div class="row hidden-mobile">
            <div class="col-12 col-md d-flex align-items-stretch">
                <div class="title text-uppercase position-relative font-lato w-100 d-flex align-items-center">
                    <div class="position-absolute w-100 h-100"></div>
                    <div class="w-100 p-4">
                        productos
                    </div>
                </div>
            </div>
            <?php echo $__env->make( 'layouts.general.dato' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="row mt-0" style="padding-top: 50px; padding-bottom: 115px;">
            <?php $__currentLoopData = $data[ "productos" ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-3 mt-4 producto wrapper-link">
                <a href="<?php echo e(URL::to( 'productos/' . str_slug( strip_tags( $p->title ) ) . '/' . $p->id )); ?>">
                    <div class="card">
                        <img src="<?php echo e(asset( $p->image[ 'i' ] )); ?>" class="card-img-top" alt="<?php echo e($p->id); ?>">
                        <div class="card-body">
                            <div class="card-text"><?php echo $p->title; ?></div>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/productos.blade.php ENDPATH**/ ?>