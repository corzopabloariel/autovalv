<header class="w-100 font-lato">
    <nav class="navbar navbar-light p-0 bg-white">
        <div style="background-image: url(<?php echo e(asset($data['empresa']['images']['header']['i'])); ?>); background-position: center; min-height: 110px; width: 100%;">
            <div class="container">
                <div class="position-relative w-100 d-flex justify-content-between align-items-center" style="height: 110px;">
                    <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
                        <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($data['empresa']['images']['logo']['i'])); ?>?t=<?php echo time(); ?>" />
                    </a>
                    <img src="<?php echo e(asset($data['empresa']['images']['icon']['i'])); ?>" alt="">
                </div>
            </div>
        </div>
        <div class="row w-100 mx-0 links">
            <a href="<?php echo e(URL::to( '/' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('/')): ?> active <?php endif; ?>">inicio</a>
            <a href="<?php echo e(URL::to( 'empresa' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('empresa*')): ?> active <?php endif; ?>">la empresa</a>
            <a href="<?php echo e(URL::to( 'productos' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('producto*')): ?> active <?php endif; ?>">productos</a>
            <a href="<?php echo e(URL::to( 'documentacion' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('documentacion*')): ?> active <?php endif; ?>">documentación</a>
            <a href="<?php echo e(URL::to( 'contacto' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('contacto')): ?> active <?php endif; ?>">contacto</a>
        </div>
    </nav>
</header><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/layouts/general/header.blade.php ENDPATH**/ ?>