<div id="menuNav" class="modal fade menuNav" tabindex="-1" role="dialog" aria-labelledby="exampleModalLiveLabel" aria-modal="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content border-top-0 border-left-0 border-bottom-0">
            <div class="modal-header bg-light">
                <h5 class="modal-title">Menú</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <ul class="list-group list-group-flush info">
                    <li class="list-group-item border-top-0 border-bottom-0 d-flex justify-content-center">
                        <a href="<?php echo e(URL::to( '/' )); ?>"><img style="max-width: 177px;" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($data['empresa']->images['logo']['i'])); ?>?t=<?php echo time(); ?>" /></a>
                    </li>
                    <li class="list-group-item text-uppercase border-top-0 mt-4 <?php if(Request::is('/')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to( '/' )); ?>">Inicio</a></li>
                    <li class="list-group-item text-uppercase <?php if(Request::is('empresa*')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('empresa')); ?>">La Empresa</a></li>
                    <li class="list-group-item text-uppercase <?php if(Request::is('productos*')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('productos')); ?>">Productos</a></li>
                    <li class="list-group-item text-uppercase <?php if(Request::is('documentacion*')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('documentacion')); ?>">Documentación</a></li>
                    <li class="list-group-item text-uppercase <?php if(Request::is('cotizacion*')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('cotizacion')); ?>">Cotización Online</a></li>
                    <li class="list-group-item text-uppercase border-bottom-0 <?php if(Request::is('contacto*')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('contacto')); ?>">Contacto</a></li>
                    
                    <li class="list-group-item text-uppercase d-flex mt-4 border-top-0">
                        <i class="fas fa-map-marker-alt mr-2"></i>
                        <div class="" style="margin-top: -6px;">
                            <p class="mb-0"><a href="<?php echo e($data[ 'empresa' ]->domicile[ 'link' ]); ?>" target="blank"><?php echo e($data[ 'empresa' ]->domicile["calle"]); ?> <?php echo e($data[ 'empresa' ]->domicile["altura"]); ?> <?php if(!empty($data[ 'empresa' ]->domicile["cp"])): ?> (<?php echo e($data[ 'empresa' ]->domicile["cp"]); ?>)<?php endif; ?><br><?php echo e($data[ 'empresa' ]->domicile["provincia"]); ?><?php if(!empty($data[ 'empresa' ]->domicile["localidad"])): ?> - <?php echo e($data[ 'empresa' ]->domicile["localidad"]); ?><?php endif; ?> | <?php echo e($data[ 'empresa' ]->domicile["pais"]); ?></a></p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<header class="w-100 font-lato">
    <nav class="navbar navbar-light p-0 bg-white">
        <div style="background-image: url(<?php echo e(asset($data['empresa']['images']['header']['i'])); ?>); background-position: center right; min-height: 110px; width: 100%; background-repeat: no-repeat; background-size: 100% 100%">
            <div class="container">
                <div class="position-relative w-100 d-flex justify-content-between align-items-center" style="height: 110px;">
                    <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
                        <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($data['empresa']['images']['logo']['i'])); ?>?t=<?php echo time(); ?>" />
                    </a>
                    <img src="<?php echo e(asset($data['empresa']['images']['icon']['i'])); ?>" alt="" class="ocsa">
                    <button class="navbar-toggler rounded-0 bg-white show-tablet" type="button" data-toggle="modal" data-target="#menuNav" style="right:0;">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="row w-100 mx-0 links">
            <a href="<?php echo e(URL::to( '/' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('/')): ?> active <?php endif; ?>">inicio</a>
            <a href="<?php echo e(URL::to( 'empresa' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('empresa*')): ?> active <?php endif; ?>">la empresa</a>
            <a href="<?php echo e(URL::to( 'productos' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('producto*')): ?> active <?php endif; ?>">productos</a>
            <a href="<?php echo e(URL::to( 'documentacion' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('documentacion*')): ?> active <?php endif; ?>">documentación</a>
            <a href="<?php echo e(URL::to( 'contacto' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('contacto*')): ?> active <?php endif; ?>">contacto</a>
        </div>
    </nav>
</header><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/layouts/general/header.blade.php ENDPATH**/ ?>