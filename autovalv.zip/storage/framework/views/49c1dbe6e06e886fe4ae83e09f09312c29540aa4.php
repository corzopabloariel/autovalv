<div id="menuNav" class="modal fade menuNav" tabindex="-1" role="dialog" aria-labelledby="exampleModalLiveLabel" aria-modal="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content border-top-0 border-left-0 border-bottom-0">
            <div class="modal-header bg-light">
                <h5 class="modal-title">Menú</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body position-relative">
                <ul class="list-group list-group-flush info position-relative" id="accordionMenuProducto">
                    <li class="list-group-item bg-transparent border-top-0 border-bottom-0 d-flex justify-content-center">
                        <a href="<?php echo e(URL::to( '/' )); ?>"><img style="max-width: 263px; width: 100%" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($data['empresa']->images['logo']['i'])); ?>?t=<?php echo time(); ?>" /></a>
                    </li>
                    <li class="list-group-item bg-transparent text-uppercase border-top-0 mt-4 <?php if(Request::is('/')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to( '/' )); ?>">Inicio</a></li>
                    <li class="list-group-item bg-transparent text-uppercase <?php if(Request::is('empresa*')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('empresa')); ?>">La Empresa</a></li>
                    <li class="list-group-item bg-transparentc p-0 text-uppercase <?php if(Request::is('productos*')): ?> active <?php endif; ?>" id="heading_productos">
                        <div class="d-flex align-items-center justify-content-between collapsed" data-toggle="collapse" data-target="#collapse_productos" <?php if(Request::is('productos*')): ?> aria-expanded="true" <?php else: ?> aria-expanded="false" <?php endif; ?> style="padding: 0.75rem 1.25rem">
                            <a href="<?php echo e(URL::to('productos')); ?>">Productos</a>
                        </div>
                        <ul class="list-group list-group-flush menu-lateral pl-2 collapse <?php if(Request::is('productos*')): ?> show <?php endif; ?>" id="collapse_productos" aria-labelledby="heading_productos" data-parent="#accordionMenuProducto">
                            <?php $__currentLoopData = $data[ "familias" ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item bg-transparent p-0" id="heading_<?php echo e($m->id); ?>">
                                <?php if( isset( $data[ 'producto' ] ) ): ?>
                                <div class="d-flex align-items-center justify-content-between collapsed" data-toggle="collapse" data-target="#collapse_<?php echo e($m->id); ?>" <?php if( $data[ 'producto' ]->familia->id == $m->id ): ?> aria-expanded="true" <?php else: ?> aria-expanded="false" <?php endif; ?> style="padding: 0.75rem 1.25rem">
                                <?php else: ?>
                                <div class="d-flex align-items-center justify-content-between collapsed" data-toggle="collapse" data-target="#collapse_<?php echo e($m->id); ?>" aria-expanded="false" style="padding: 0.75rem 1.25rem">
                                <?php endif; ?>
                                    <?php
                                    $productos = $m->productos;
                                    ?>
                                    <a class="bg-transparent pl-2" href="<?php echo e(URL::to( 'productos/' . str_slug( strip_tags( $m->title ) ) . '/' . $m->id )); ?>">
                                        <?php echo $m->title; ?>

                                    </a>
                                    <?php if( count( $productos ) > 0 ): ?>
                                    <i class="fas fa-angle-right"></i>
                                    <?php endif; ?>
                                </div>
                                <?php if( count( $productos ) > 0 ): ?>
                                    <?php if( isset( $data[ 'producto' ]->familia->id ) ): ?>
                                    <ul class="list-group collapse <?php if( $data[ 'producto' ]->familia->id == $m->id ): ?> show <?php endif; ?>" id="collapse_<?php echo e($m->id); ?>" aria-labelledby="heading_<?php echo e($m->id); ?>" data-parent="#accordionMenu">
                                    <?php else: ?>
                                    <ul class="list-group collapse" id="collapse_<?php echo e($m->id); ?>" aria-labelledby="heading_<?php echo e($m->id); ?>" data-parent="#accordionMenu">
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item bg-transparent p-0">
                                        <a href="<?php echo e(URL::to( 'productos/' . str_slug( strip_tags( $m->title ) ) . '/' . str_slug( $f->title ) . '/' . $f->id )); ?>" class="p-3 d-block">
                                            <i class="fas fa-arrow-right mr-2"></i><?php echo $f->title; ?>

                                        </a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <li class="list-group-item bg-transparent text-uppercase d-none d-lg-block <?php if(Request::is('documentacion*')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('documentacion')); ?>">Documentación</a></li>
                    <li class="list-group-item bg-transparent text-uppercase border-bottom-0 <?php if(Request::is('contacto*')): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('contacto')); ?>">Contacto</a></li>
                    <img src="<?php echo e(asset($data['empresa']['images']['icon']['i'])); ?>" alt="" style="opacity: .15; top: calc( 50% - 75px ); z-index: 0; left: calc( 50% - 119px ); width: 238px" class="ocsa mt-4 d-block position-absolute isDisabled">
                </ul>
            </div>
        </div>
    </div>
</div>
<header class="w-100 font-lato">
    <nav class="navbar navbar-light p-0 bg-white">
        <div style="background-image: url(<?php echo e(asset($data['empresa']['images']['header']['i'])); ?>); background-position: center right; min-height: 110px; width: 100%; background-repeat: no-repeat; background-size: 100% 100%">
            <div class="container">
                <div class="position-relative w-100 d-flex justify-content-between align-items-center" style="height: 110px;">
                    <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
                        <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($data['empresa']['images']['logo']['i'])); ?>?t=<?php echo time(); ?>" />
                    </a>
                    <img src="<?php echo e(asset($data['empresa']['images']['icon']['i'])); ?>" alt="" class="ocsa d-none d-lg-block">
                    <button class="navbar-toggler rounded-0 bg-white show-tablet" type="button" data-toggle="modal" data-target="#menuNav" style="right:0;">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="row w-100 mx-0 links">
            <a href="<?php echo e(URL::to( '/' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('/')): ?> active <?php endif; ?>">inicio</a>
            <a href="<?php echo e(URL::to( 'empresa' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('empresa*')): ?> active <?php endif; ?>">la empresa</a>
            <a href="<?php echo e(URL::to( 'productos' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('producto*')): ?> active <?php endif; ?>">productos</a>
            <a href="<?php echo e(URL::to( 'documentacion' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('documentacion*')): ?> active <?php endif; ?>">documentación</a>
            <a href="<?php echo e(URL::to( 'contacto' )); ?>" class="col-12 col-md text-center py-2 text-uppercase <?php if(Request::is('contacto*')): ?> active <?php endif; ?>">contacto</a>
        </div>
    </nav>
</header><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/layouts/general/header.blade.php ENDPATH**/ ?>