<footer>
    <div class="container pt-5">
        <div class="row justify-content-start">
            <div class="col-12 col-md-4 col-lg-5 d-flex align-items-center">
                <div class="">
                    <img class="logo align-self-center" src="<?php echo e(asset($data['empresa']['images']['logoFooter']['i'])); ?>" alt="" srcset="">
                </div>
            </div>
            <?php
            $A_tel = $A_wha = [];
            foreach($data["empresa"]->phone AS $t) {
                if($t["tipo"] == "tel")
                    $A_tel[] = $t;
                else
                    $A_wha[] = $t;
            }
            ?>
            <div class="col-12 col-md-4 col-lg">
                
                <ul class="list-unstyled info mb-0">
                    <li class="d-flex pt-1">
                        <i style="margin-right:10px;" class="icono fas fa-map-marker-alt"></i>
                        <div class="" style="margin-top: -5px; width: calc(100% - 37px)" >
                            <p class="mb-0"><a href="<?php echo e($data[ 'empresa' ]->domicile[ 'link' ]); ?>" target="blank"><?php echo e($data[ 'empresa' ]->domicile["calle"]); ?> <?php echo e($data[ 'empresa' ]->domicile["altura"]); ?> <?php if(!empty($data[ 'empresa' ]->domicile["cp"])): ?> (<?php echo e($data[ 'empresa' ]->domicile["cp"]); ?>)<?php endif; ?><br><?php echo e($data[ 'empresa' ]->domicile["provincia"]); ?><?php if(!empty($data[ 'empresa' ]->domicile["localidad"])): ?> - <?php echo e($data[ 'empresa' ]->domicile["localidad"]); ?><?php endif; ?> | <?php echo e($data[ 'empresa' ]->domicile["pais"]); ?></a></p>
                        </div>
                    </li>
                    <li class="d-flex mt-2">
                        <i style="margin-right:10px;" class="icono far fa-envelope"></i>
                        <div class="" style="margin-top: -5px; width: calc(100% - 37px)">
                            <?php $__currentLoopData = $data["empresa"]["email"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo e($e); ?>" class="text-truncate d-block" href="mailto:<?php echo $e; ?>" target="blank"><?php echo $e; ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-4 col-lg">
                <ul class="list-unstyled info mb-0">
                    <li class="d-flex pt-1">
                        <i style="margin-right:10px;" class="icono fas fa-phone-volume"></i>
                        <div class="" style="margin-top: -5px; width: calc(100% - 37px)">
                            <?php $__currentLoopData = $A_tel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $visible = $t[ "telefono" ];
                                $telefono = $t[ "telefono" ];
                                if( !empty( $t[ "visible" ] ) )
                                    $visible = $t[ "visible" ];
                                ?>
                                <?php if( $t[ "is_link" ] ): ?>
                                    <a title="<?php echo e($visible); ?>" class="text-truncate d-block" href="tel:<?php echo e($telefono); ?>"><?php echo e($visible); ?></a>
                                <?php else: ?>
                                    <?php echo e($visible); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                    <?php if(!empty($A_wha)): ?>
                    <li class="d-flex mt-2">
                        <i class="fab fa-whatsapp" style="color:#4DC95C; margin-right:10px;"></i>
                        <div class="" style="margin-top: -5px; width: calc(100% - 37px)">
                            <?php $__currentLoopData = $A_wha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo e($t['visible']); ?>" class="whatsapp text-truncate d-block" target="blank" href="https://wa.me/<?php echo $t['telefono']; ?>"><?php echo e($t["visible"]); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <div class="row mt-3 frase">
            <div class="col-12"><div><?php echo $data[ "empresa" ]->footer[ "text" ]; ?></div></div>
        </div>
    </div>
</footer>
<div class="osole py-2">
    <div class="container">
        <div class="row by">
            <div class="col-12">
                <hr class="my-2"/>
                <p class="mb-0 d-flex justify-content-between">
                    <span>© <?php echo e(env( 'APP_YEAR' )); ?></span>
                    <a target="_blank" href="<?php echo e(env('APP_UAUTHOR')); ?>" style="color:inherit" class="right text-uppercase">by <?php echo e(env('APP_AUTHOR')); ?></a>
                </p>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/layouts/general/footer.blade.php ENDPATH**/ ?>