<div class="d-flex h-100 align-items-center justify-content-center py-5">
    <h1>Bienvenido<br/><?php echo e(Auth::user()["name"]); ?></h1>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/auth/parts/index.blade.php ENDPATH**/ ?>