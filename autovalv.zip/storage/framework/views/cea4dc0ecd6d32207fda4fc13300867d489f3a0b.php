<!DOCTYPE html>
<html>
<body>
    <h2>Cotización</h2>
    <br/>
    <h3>Datos personales</h3>
	<ul>
        <li><strong>Nombre:</strong> <?php echo e($nombre); ?></li>
        <li><strong>Empresa:</strong> <?php echo e($empresa); ?></li>
        <li><strong>Cargo:</strong> <?php echo e($cargo); ?></li>
        <li><strong>Email:</strong> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></li>
        <li><strong>Teléfono:</strong> <?php echo e($telefono); ?></li>
	</ul>
    <br>
    <h3>Datos técnicos</h3>
    <ul>
        <li><strong>Accionamiento:</strong> <?php echo e($accionamiento); ?></li>
        <li><strong>Fluido:</strong> <?php echo e($fluido); ?></li>
        <li><strong>Configuración:</strong> <?php echo e($configuracion); ?></li>
        <li><strong>Temperatura del trabajo (ºC):</strong> <?php echo e($temperaturaTrabajo); ?></li>
        <li><strong>Medida de conexión:</strong> <?php echo e($conexion); ?></li>
        <li><strong>Presión de trabajo:</strong> <?php echo e($presionTrabajo); ?></li>
        <li><strong>Tipo de conexión:</strong> <?php echo e($conexionTipo); ?></li>
        <li><strong>Tensión de trabajo:</strong> <?php echo e($tensionTrabajo); ?></li>
        <li><strong>Material del cuerpo:</strong> <?php echo e($configuracion); ?></li>
        <li><strong>Código de válvula:</strong> <?php echo e($codigoValvula); ?></li>
    </ul>
    <h4>Mensaje</h4>
    <p><?php echo e($mensaje); ?></p>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/form/cotizacion.blade.php ENDPATH**/ ?>