<section class="mt-3">
    <div class="container-fluid">
        <?php echo $__env->make( 'auth.parts.contenido.' . $data[ "section" ] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/auth/parts/contenido.blade.php ENDPATH**/ ?>