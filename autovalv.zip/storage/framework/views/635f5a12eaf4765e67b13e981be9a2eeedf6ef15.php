<div class="wrapper-documentacion bg-white font-lato" style="padding-top: 15px;">
    <div class="container">
        <div class="row" style="padding-bottom: 15px;">
            <div class="col-12 col-md d-flex align-items-stretch">
                <div class="title text-uppercase position-relative font-lato w-100 d-flex align-items-center">
                    <div class="position-absolute w-100 h-100"></div>
                    <div class="w-100 p-4">
                        documentación
                    </div>
                </div>
            </div>
            <?php echo $__env->make( 'layouts.general.dato' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="row font-lato pb-5">
            <?php $__currentLoopData = $data[ "documentacion" ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-4 col-lg-3 mt-3 text-center">
                <div class="card mx-auto border-0">
                    <img src="<?php echo e(asset( $d->cover[ 'i' ])); ?>" alt="" class="card-img-top border border-bottom-0">
                    <div class="card-body border">
                        <?php echo e($d->title); ?>

                    </div>
                    <?php if( file_exists( public_path() . "/" . $d->file[ 'i' ] ) ): ?>
                    <div class="card-footer d-flex justify-content-around border-0 bg-transparent">
                        <a href="<?php echo e(asset( $d->file[ 'i' ] )); ?>" target="blank"><i class="fas fa-eye"></i></a>
                        <a href="<?php echo e(asset( $d->file[ 'i' ] )); ?>" download><i class="fas fa-download"></i></a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/documentacion.blade.php ENDPATH**/ ?>