<div class="wrapper-terminos bg-white font-lato wrapper-">
    <div class="container">
        <div class="row pb-5 mt-0 wrapper- normal">
            <div class="col-12">
                <h3 class="title"><?php echo e($data[ "contenido" ]->content[ "title" ]); ?></h3>
                <div class="mt-4 text">
                    <?php echo $data[ "contenido" ]->content[ "text" ]; ?>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\autovalv\resources\views/page/terminos.blade.php ENDPATH**/ ?>